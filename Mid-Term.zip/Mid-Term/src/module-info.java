/**
 * 
 */
/**
 * @author hello
 *
 */
module midterm {
	requires java.desktop;
}