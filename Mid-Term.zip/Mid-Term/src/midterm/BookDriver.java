package midterm;

import javax.swing.JOptionPane;

public class BookDriver {
	public static void main(String[] args) {
					// TODO Auto-generated method stub
					// Asking questions with the user
				 String title = JOptionPane.showInputDialog("Enter the book title:");
				        String ISBN = JOptionPane.showInputDialog("Enter the book ISBN:");
				        String publisher = JOptionPane.showInputDialog("Enter the book publisher:");
				        int year = Integer.parseInt(JOptionPane.showInputDialog("Enter the book year:"));
			
				        String genreInput = JOptionPane.showInputDialog("Enter the genre of the book (Science/Children):");
			
				        Book book;
				        if (genreInput.equalsIgnoreCase("Science")) {
				            double price = Double.parseDouble(JOptionPane.showInputDialog("Enter the book price:"));
				            book = new ScienceBook(title, ISBN, publisher, year);
				            book.setPrice(price);
				        } else if (genreInput.equalsIgnoreCase("Children")) {
				            double price = Double.parseDouble(JOptionPane.showInputDialog("Enter the fixed price for children's book:"));
				            book = new ChildrenBook(title, ISBN, publisher, year);
				            book.setPrice(price);
				        } else {
				            JOptionPane.showMessageDialog(null, "Invalid genre.");
				            return;
				        }
				     // Display book information
				        String bookInfo = book.toString() + "\nGenre: " + book.getGenre() + "\nPrice: $" + book.getPrice();
				        JOptionPane.showMessageDialog(null, bookInfo);
			
			
				}	
}//BookDriver
