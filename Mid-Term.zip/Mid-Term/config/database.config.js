module.exports = {
    url: 'mongodb+srv://hellopeter1018:kISN6GCsMrThWp8Q@cluster0.ndww0ij.mongodb.net/'
}